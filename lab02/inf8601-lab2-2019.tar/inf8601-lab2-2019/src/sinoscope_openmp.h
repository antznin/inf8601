/*
 * sinoscope_openmp.h
 *
 *  Created on: 2011-10-14
 *      Author: francis
 */

#ifndef SINOSCOPE_OPENMP_H_
#define SINOSCOPE_OPENMP_H_

int sinoscope_image_openmp(sinoscope_t *b_ptr);

#endif /* SINOSCOPE_OPENMP_H_ */
